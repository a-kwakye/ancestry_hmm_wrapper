# Ancestry HMM Pipeline v0.2.1

A genome-agnostic command-line wrapper around **two- or three-population** diploid Ancestry_HMM workflows. Version 0.2 removes the original Drosophila-specific population names, sample-name inference, and chromosome-arm mapping.

## Scope

v0.2 supports:

- any genome/chromosome labels that PLINK 1.9 can import;
- either two or three reference ancestry populations with arbitrary names;
- explicit target sample lists;
- arbitrary chromosome labels in posterior plots;
- configurable recombination-map column names;
- recombination rates in `cM/Mb` or `M/bp`;
- configurable global or per-sample ploidy in the Ancestry_HMM sample file;
- parallel Ancestry_HMM execution;
- length-weighted or SNP-weighted ancestry summaries;
- ancestry-distribution plots for arbitrary sample groups;
- generalized high/low chromosome paintings.

The posterior parser automatically uses the three diploid states for two populations (`2,0`, `1,1`, `0,2`) or the six diploid states for three populations (`2,0,0`, `1,1,0`, `1,0,1`, `0,2,0`, `0,1,1`, `0,0,2`).

## Requirements

- Python 3.9+
- PLINK 1.9 (`plink`) on PATH, or `--plink /path/to/plink`
- `ancestry_hmm` on PATH, or `--executable /path/to/ancestry_hmm`
- Python: numpy, pandas, matplotlib

## Install

```bash
python3 -m pip install ancestry_hmm_pipeline-0.2.1-py3-none-any.whl
ancestry-pipeline --help
```

## Input files

### Reference keep files

One sample ID per line (or PLINK-style `0 SAMPLE_ID`). Supply two or three populations. Their order becomes ancestry indices 0, 1, and optionally 2:

```bash
--population Coastal=coastal.keep \
--population River=river.keep \
--population Lake=lake.keep
```

### Target samples

Optional `targets.txt`, one sample ID per line. If omitted, all VCF samples become targets.

### Population map

Used for grouping samples in distribution plots and chromosome painting:

```text
sample population
fish01 Coastal
fish02 Coastal
fish03 River
fish04 Lake
```

No population is inferred from a sample name.

### Recombination map

Any delimited table is accepted as long as the chromosome, start, stop, and rate columns are identified. Defaults retain compatibility with the original Comeron-format map:

```text
Arm    Start    Stop    c (cM/Mb)
1      1        100000  1.2
1      100001   200000  0.8
```

For a map with columns `chrom`, `begin`, `end`, and `rate`, use:

```bash
--map-chrom-col chrom \
--map-start-col begin \
--map-stop-col end \
--map-rate-col rate
```

Stops are treated as inclusive by default. Use `--map-stop-exclusive` if your map uses half-open intervals.

### Chromosome display map

Optional two-column file used only for plotting labels/order:

```text
chrom label
1 chr1
2 chr2
23 chrX
```

It does not alter the HMM input chromosome values.

### Ploidy map

The default target ploidy is 2. Override individual targets with:

```text
sample ploidy
sampleA 2
sampleB 1
```

using `--ploidy-map ploidy.tsv`.

## End-to-end example

```bash
ancestry-pipeline run \
  --vcf cohort.vcf.gz \
  --map recombination_map.tsv \
  --population Coastal=coastal.keep \
  --population River=river.keep \
  --population Lake=lake.keep \
  --target-samples targets.txt \
  --population-map population_map.tsv \
  --chromosomes 1 2 3 4 5 6 7 8 9 10 23 \
  --chromosome-map chromosome_labels.tsv \
  --jobs 24 \
  --priors 0.85 0.10 0.05 \
  --pulse 2,-1000,0.05 \
  --pulse 0,10000,0.85 \
  --pulse 1,-100,0.10 \
  --state-order Lake Coastal River \
  --outdir ancestry_analysis
```

`--population` order defines reference indices. `--state-order` describes the posterior component order and must contain the same two or three population names.

## Two-population example

For two references, provide two `--population` entries, two priors, pulse ancestry indices 0 or 1, and two names in `--state-order`:

```bash
ancestry-pipeline run \
  --vcf cohort.vcf.gz \
  --map recombination_map.tsv \
  --population ZI=zambia.keep \
  --population FR=france.keep \
  --target-samples targets.txt \
  --population-map population_map.tsv \
  --jobs 24 \
  --priors 0.1 0.9 \
  --pulse 1,100000,0.9 \
  --pulse 0,-100,0.1 \
  --state-order ZI FR \
  --outdir ancestry_2pop
```

Ancestry_HMM is invoked with `-a 2`. The expected diploid posterior columns are `2,0`, `1,1`, and `0,2`.

## Individual commands

```bash
ancestry-pipeline build --help
ancestry-pipeline split --help
ancestry-pipeline run-hmm --help
ancestry-pipeline summarize --help
ancestry-pipeline distributions --help
ancestry-pipeline paint --help
ancestry-pipeline run --help
```

Example generalized painting:

```bash
ancestry-pipeline paint \
  --population Coastal \
  --sample-group Coastal \
  --group high \
  --summary ancestry_summary.tsv \
  --posterior-dir ancestry_hmm_results/posteriors \
  --population-map population_map.tsv \
  --state-order Lake Coastal River \
  --chromosome-map chromosome_labels.tsv \
  --threshold 0.9 \
  --out high_coastal_ancestry.pdf
```

## Output layout

```text
ancestry_analysis/
├── panel/
│   ├── panel_all_chroms.tsv
│   ├── samples_all_chroms.txt
│   ├── population_order.tsv
│   └── sample_membership.tsv
├── per_sample/
├── hmm/
│   ├── posteriors/
│   │   └── SAMPLE.posterior
│   └── run_summary.tsv
├── summaries/
│   └── ancestry_summary.tsv
└── plots/
    ├── ancestry_distributions.pdf
    ├── ancestry_distributions.png
    └── chromosome_paintings/
```

## Important limitations

1. The workflow supports two or three ancestry populations.
2. Posterior state handling is diploid: three states for two populations and six states for three populations. Although a per-sample ploidy value can be passed to Ancestry_HMM, the v0.2.1 summarizer/painter is intended for diploid posterior output.
3. PLINK chromosome-name handling varies by organism and PLINK settings. If a nonstandard genome uses chromosome names PLINK 1.9 does not recognize directly, preprocess/recode chromosome labels before running the panel builder.
4. Recombination-map chromosome labels must match the chromosome labels emitted by PLINK's `.traw` file.
